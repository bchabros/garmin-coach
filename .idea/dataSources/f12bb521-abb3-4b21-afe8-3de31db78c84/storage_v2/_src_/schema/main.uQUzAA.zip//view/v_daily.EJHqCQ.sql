CREATE VIEW v_daily AS
SELECT d.date,
       m.hrv, m.hrv_baseline, m.hrv_low_flag,
       m.acwr, m.n_chronic,
       m.load_day, m.load_low, m.load_high, m.load_anaerobic,
       s.total_s/3600.0 AS sleep_h, s.deep_s/60.0 AS deep_min, s.rem_s/60.0 AS rem_min,
       s.score AS sleep_score, s.resting_hr AS rhr, s.skin_temp_dev_c,
       w.bb_min, w.bb_max, w.stress_avg,
       tr.score AS readiness, tr.level AS readiness_level,
       ts.status AS training_status, ts.balance_phrase, ts.vo2max
FROM daily_wellness d
LEFT JOIN daily_metrics       m  ON m.date  = d.date
LEFT JOIN sleep               s  ON s.date  = d.date
LEFT JOIN hrv_nightly         h  ON h.date  = d.date
LEFT JOIN daily_wellness      w  ON w.date  = d.date
LEFT JOIN training_readiness  tr ON tr.date = d.date
LEFT JOIN training_status_daily ts ON ts.date = d.date;

