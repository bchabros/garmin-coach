CREATE VIEW v_flags AS
SELECT date, hrv, hrv_low_flag, acwr, n_chronic, rhr_delta, illness_watch
FROM daily_metrics
WHERE hrv_low_flag = 1
   OR illness_watch = 1
   OR (n_chronic >= 28 AND (acwr > 1.5 OR acwr < 0.8));

