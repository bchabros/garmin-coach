CREATE VIEW v_activity_enriched AS
SELECT a.*,
       CASE WHEN a.distance_m > 0 AND a.avg_speed_mps > 0
            THEN (1000.0/a.avg_speed_mps)/60.0 END AS pace_min_km,
       CASE WHEN a.anaero_te >= 1.0 THEN 'anaerobic'
            WHEN a.aero_te   <  2.5 THEN 'aerobic_low'
            ELSE 'aerobic_high' END AS load_bucket
FROM activities a;

